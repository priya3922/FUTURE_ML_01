"""
Sales & Demand Forecasting for Businesses
Future Interns - Machine Learning Task 1 (2026)

Pipeline:
 1. Generate a realistic retail sales dataset (simulated Superstore-style data,
    representing a real multi-region, multi-category retail business)
 2. Clean the data (missing values, duplicates, negative/invalid entries)
 3. Engineer time-based features (date parts, seasonality, lags, rolling stats)
 4. Train forecasting models (Linear Regression baseline + Random Forest)
 5. Evaluate with MAE, RMSE, MAPE, R^2 on a held-out future period
 6. Forecast the next 90 days and visualize everything for business stakeholders
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

RNG = np.random.default_rng(42)
OUT_DIR = "/home/claude/sales_forecast"
CHART_DIR = f"{OUT_DIR}/charts"
DATA_DIR = f"{OUT_DIR}/data"

plt.rcParams["figure.dpi"] = 110
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.alpha"] = 0.3

# ---------------------------------------------------------------------------
# 1. GENERATE A REALISTIC RETAIL SALES DATASET
# ---------------------------------------------------------------------------
# Simulated "Superstore"-style daily sales for a mid-size retail business,
# 3 years of history, across 3 regions and 4 product categories, with:
#   - a gentle upward growth trend (business is growing)
#   - weekly seasonality (weekends busier)
#   - yearly seasonality (Nov-Dec holiday peak, summer lull)
#   - occasional promo spikes
#   - random noise
# This mirrors publicly available retail datasets (e.g. Kaggle Superstore /
# Store Sales Time Series Forecasting) closely enough to demonstrate the
# full workflow while keeping the project fully self-contained and reproducible.

def generate_raw_dataset():
    start = pd.Timestamp("2023-01-01")
    end = pd.Timestamp("2025-12-31")
    dates = pd.date_range(start, end, freq="D")

    regions = ["East", "West", "South"]
    categories = ["Furniture", "Office Supplies", "Technology", "Clothing"]

    rows = []
    for region in regions:
        region_mult = {"East": 1.15, "West": 1.0, "South": 0.85}[region]
        for category in categories:
            cat_base = {
                "Furniture": 420, "Office Supplies": 260,
                "Technology": 520, "Clothing": 300,
            }[category]

            n = len(dates)
            t = np.arange(n)

            trend = cat_base + t * (cat_base * 0.00035)  # slow organic growth
            weekly = 1 + 0.18 * (pd.Series(dates).dt.dayofweek.isin([4, 5, 6]).astype(int).values)
            doy = pd.Series(dates).dt.dayofyear.values
            yearly = 1 + 0.30 * np.sin(2 * np.pi * (doy - 80) / 365.25) \
                       + 0.35 * np.exp(-((doy - 340) ** 2) / (2 * 12 ** 2))  # holiday bump ~Dec
            noise = RNG.normal(0, cat_base * 0.09, n)

            # occasional promo spikes (~1.5% of days)
            promo = RNG.random(n) < 0.015
            promo_effect = np.where(promo, RNG.uniform(0.4, 0.9, n) * cat_base, 0)

            sales = trend * weekly * yearly * region_mult + noise + promo_effect
            sales = np.clip(sales, 20, None)

            units = np.clip((sales / RNG.uniform(18, 34, n)).round(), 1, None)

            for i, d in enumerate(dates):
                rows.append((d, region, category, round(sales[i], 2), int(units[i])))

    df = pd.DataFrame(rows, columns=["Order Date", "Region", "Category", "Sales", "Units Sold"])

    # ---- deliberately inject realistic messiness to clean later ----
    dirty = df.copy()
    dirty_idx = RNG.choice(dirty.index, size=int(len(dirty) * 0.01), replace=False)
    dirty.loc[dirty_idx, "Sales"] = np.nan          # missing values
    dup_idx = RNG.choice(dirty.index, size=40, replace=False)
    dirty = pd.concat([dirty, dirty.loc[dup_idx]], ignore_index=True)  # duplicate rows
    neg_idx = RNG.choice(dirty.index, size=15, replace=False)
    dirty.loc[neg_idx, "Sales"] = -abs(dirty.loc[neg_idx, "Sales"])    # bad negative entries

    dirty.to_csv(f"{DATA_DIR}/raw_sales_data.csv", index=False)
    return dirty


# ---------------------------------------------------------------------------
# 2. CLEAN THE DATA
# ---------------------------------------------------------------------------
def clean_data(df):
    df = df.copy()
    before = len(df)

    df = df.drop_duplicates()
    df = df.dropna(subset=["Sales"])
    df = df[df["Sales"] > 0]

    df["Order Date"] = pd.to_datetime(df["Order Date"])
    df = df.sort_values("Order Date")

    print(f"Cleaning: {before} -> {len(df)} rows "
          f"(removed {before - len(df)} bad/duplicate/missing rows)")

    # aggregate to a single business-level daily sales series
    daily = df.groupby("Order Date", as_index=False)["Sales"].sum()
    daily = daily.rename(columns={"Order Date": "date", "Sales": "sales"})

    # fill any missing calendar days (store closures etc.) via interpolation
    full_range = pd.date_range(daily["date"].min(), daily["date"].max(), freq="D")
    daily = daily.set_index("date").reindex(full_range)
    daily["sales"] = daily["sales"].interpolate(method="linear")
    daily.index.name = "date"
    daily = daily.reset_index()

    daily.to_csv(f"{DATA_DIR}/clean_daily_sales.csv", index=False)
    return daily


# ---------------------------------------------------------------------------
# 3. TIME-BASED FEATURE ENGINEERING
# ---------------------------------------------------------------------------
def add_features(daily):
    df = daily.copy()
    df["year"] = df["date"].dt.year
    df["month"] = df["date"].dt.month
    df["day"] = df["date"].dt.day
    df["dayofweek"] = df["date"].dt.dayofweek
    df["dayofyear"] = df["date"].dt.dayofyear
    df["weekofyear"] = df["date"].dt.isocalendar().week.astype(int)
    df["is_weekend"] = df["dayofweek"].isin([4, 5, 6]).astype(int)

    # cyclical encodings so the model understands seasonality wraps around
    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12)
    df["dow_sin"] = np.sin(2 * np.pi * df["dayofweek"] / 7)
    df["dow_cos"] = np.cos(2 * np.pi * df["dayofweek"] / 7)
    df["doy_sin"] = np.sin(2 * np.pi * df["dayofyear"] / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * df["dayofyear"] / 365.25)

    # trend index (days since start) captures business growth
    df["t"] = (df["date"] - df["date"].min()).dt.days

    # lag & rolling features (recent momentum)
    df["lag_7"] = df["sales"].shift(7)
    df["lag_14"] = df["sales"].shift(14)
    df["lag_28"] = df["sales"].shift(28)
    df["rolling_mean_7"] = df["sales"].shift(1).rolling(7).mean()
    df["rolling_mean_28"] = df["sales"].shift(1).rolling(28).mean()

    df = df.dropna().reset_index(drop=True)
    return df


FEATURES = [
    "t", "month_sin", "month_cos", "dow_sin", "dow_cos", "doy_sin", "doy_cos",
    "is_weekend", "lag_7", "lag_14", "lag_28", "rolling_mean_7", "rolling_mean_28",
]


# ---------------------------------------------------------------------------
# 4. TRAIN / TEST SPLIT + MODELS
# ---------------------------------------------------------------------------
def train_and_evaluate(feat_df):
    test_days = 90
    train = feat_df.iloc[:-test_days]
    test = feat_df.iloc[-test_days:]

    X_train, y_train = train[FEATURES], train["sales"]
    X_test, y_test = test[FEATURES], test["sales"]

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=300, max_depth=8, random_state=42, n_jobs=-1
        ),
    }

    results = {}
    preds = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        preds[name] = pred
        mae = mean_absolute_error(y_test, pred)
        rmse = np.sqrt(mean_squared_error(y_test, pred))
        mape = np.mean(np.abs((y_test.values - pred) / y_test.values)) * 100
        r2 = r2_score(y_test, pred)
        results[name] = {"MAE": mae, "RMSE": rmse, "MAPE": mape, "R2": r2}
        print(f"{name:20s} MAE={mae:8.1f}  RMSE={rmse:8.1f}  MAPE={mape:5.2f}%  R2={r2:5.3f}")

    best_name = min(results, key=lambda k: results[k]["MAE"])
    print(f"\nBest model: {best_name}")

    return models, results, preds, best_name, train, test


# ---------------------------------------------------------------------------
# 5. FUTURE FORECAST (next 90 days), refit best model on ALL data
# ---------------------------------------------------------------------------
def forecast_future(feat_df, models, best_name, horizon=90):
    best_model = models[best_name]
    best_model.fit(feat_df[FEATURES], feat_df["sales"])  # refit on full history

    history = feat_df[["date", "sales"]].copy()
    last_date = history["date"].max()
    sales_series = list(feat_df["sales"].values)
    future_rows = []

    for i in range(1, horizon + 1):
        d = last_date + pd.Timedelta(days=i)
        t = (d - feat_df["date"].min()).days
        month, dow, doy = d.month, d.dayofweek, d.dayofyear
        row = {
            "date": d,
            "t": t,
            "month_sin": np.sin(2 * np.pi * month / 12),
            "month_cos": np.cos(2 * np.pi * month / 12),
            "dow_sin": np.sin(2 * np.pi * dow / 7),
            "dow_cos": np.cos(2 * np.pi * dow / 7),
            "doy_sin": np.sin(2 * np.pi * doy / 365.25),
            "doy_cos": np.cos(2 * np.pi * doy / 365.25),
            "is_weekend": int(dow in [4, 5, 6]),
            "lag_7": sales_series[-7],
            "lag_14": sales_series[-14],
            "lag_28": sales_series[-28],
            "rolling_mean_7": np.mean(sales_series[-7:]),
            "rolling_mean_28": np.mean(sales_series[-28:]),
        }
        pred = best_model.predict(pd.DataFrame([row])[FEATURES])[0]
        sales_series.append(pred)
        row["forecast_sales"] = pred
        future_rows.append(row)

    future_df = pd.DataFrame(future_rows)[["date", "forecast_sales"]]
    future_df.to_csv(f"{DATA_DIR}/future_90day_forecast.csv", index=False)
    return future_df


# ---------------------------------------------------------------------------
# 6. VISUALIZATIONS (business-friendly)
# ---------------------------------------------------------------------------
def plot_history_overview(daily):
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.plot(daily["date"], daily["sales"], color="#2E5FA3", linewidth=0.9)
    ax.set_title("Daily Sales — Full History (2023–2025)", fontsize=13, fontweight="bold")
    ax.set_ylabel("Sales ($)")
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=4))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/01_history_overview.png")
    plt.close(fig)


def plot_trend_seasonality(daily):
    df = daily.copy()
    df["ma_30"] = df["sales"].rolling(30, center=True).mean()
    df["month"] = df["date"].dt.month
    monthly_avg = df.groupby("month")["sales"].mean()
    dow_avg = df.groupby(df["date"].dt.dayofweek)["sales"].mean()

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    axes[0].plot(df["date"], df["sales"], color="#c9d6e6", linewidth=0.6, label="Daily")
    axes[0].plot(df["date"], df["ma_30"], color="#2E5FA3", linewidth=1.8, label="30-day trend")
    axes[0].set_title("Underlying Trend")
    axes[0].legend(fontsize=8)
    axes[0].xaxis.set_major_locator(mdates.YearLocator())
    axes[0].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))

    axes[1].bar(monthly_avg.index, monthly_avg.values, color="#E08E45")
    axes[1].set_title("Avg Sales by Month (Yearly Seasonality)")
    axes[1].set_xticks(range(1, 13))
    axes[1].set_xlabel("Month")

    labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    axes[2].bar(labels, dow_avg.values, color="#4E9B67")
    axes[2].set_title("Avg Sales by Day of Week")

    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/02_trend_seasonality.png")
    plt.close(fig)


def plot_test_predictions(test, preds, results):
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.plot(test["date"], test["sales"], label="Actual", color="black", linewidth=1.4)
    colors = {"Linear Regression": "#E08E45", "Random Forest": "#2E5FA3"}
    for name, pred in preds.items():
        ax.plot(test["date"], pred, label=f"{name} (MAE {results[name]['MAE']:.0f})",
                 color=colors.get(name), linewidth=1.4, linestyle="--")
    ax.set_title("Model Validation — Last 90 Days (Actual vs Predicted)", fontsize=13, fontweight="bold")
    ax.set_ylabel("Sales ($)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/03_test_predictions.png")
    plt.close(fig)


def plot_future_forecast(feat_df, future_df, best_name):
    fig, ax = plt.subplots(figsize=(11, 4.5))
    recent = feat_df[feat_df["date"] >= feat_df["date"].max() - pd.Timedelta(days=180)]
    ax.plot(recent["date"], recent["sales"], label="Historical Sales", color="black", linewidth=1.2)
    ax.plot(future_df["date"], future_df["forecast_sales"],
             label=f"Forecast (next 90 days) — {best_name}", color="#C0392B", linewidth=1.6)
    ax.axvline(feat_df["date"].max(), color="gray", linestyle=":", linewidth=1)
    ax.fill_between(future_df["date"],
                     future_df["forecast_sales"] * 0.90,
                     future_df["forecast_sales"] * 1.10,
                     color="#C0392B", alpha=0.12, label="±10% planning band")
    ax.set_title("90-Day Sales Forecast for Business Planning", fontsize=13, fontweight="bold")
    ax.set_ylabel("Sales ($)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/04_future_forecast.png")
    plt.close(fig)


def plot_feature_importance(models, best_name):
    model = models[best_name]
    if not hasattr(model, "feature_importances_"):
        return
    importances = pd.Series(model.feature_importances_, index=FEATURES).sort_values()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(importances.index, importances.values, color="#2E5FA3")
    ax.set_title(f"What Drives the Forecast? — {best_name} Feature Importance",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/05_feature_importance.png")
    plt.close(fig)


def plot_monthly_business_summary(feat_df, future_df):
    hist_monthly = feat_df.set_index("date")["sales"].resample("MS").sum()
    fut_monthly = future_df.set_index("date")["forecast_sales"].resample("MS").sum()

    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.bar(hist_monthly.index[-6:], hist_monthly.values[-6:], width=20,
           color="#7f8fa6", label="Actual (last 6 months)")
    ax.bar(fut_monthly.index, fut_monthly.values, width=20,
           color="#C0392B", label="Forecast (next months)")
    ax.set_title("Monthly Sales — Recent Actuals vs Forecast", fontsize=13, fontweight="bold")
    ax.set_ylabel("Total Monthly Sales ($)")
    ax.legend()
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(f"{CHART_DIR}/06_monthly_business_summary.png")
    plt.close(fig)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("Step 1: Generating raw dataset...")
    raw = generate_raw_dataset()

    print("\nStep 2: Cleaning data...")
    daily = clean_data(raw)

    print("\nStep 3: Engineering time-based features...")
    feat_df = add_features(daily)

    print("\nStep 4: Training & evaluating models...")
    models, results, preds, best_name, train, test = train_and_evaluate(feat_df)

    print("\nStep 5: Forecasting next 90 days...")
    future_df = forecast_future(feat_df, models, best_name)

    print("\nStep 6: Building visualizations...")
    plot_history_overview(daily)
    plot_trend_seasonality(daily)
    plot_test_predictions(test, preds, results)
    plot_future_forecast(feat_df, future_df, best_name)
    plot_feature_importance(models, best_name)
    plot_monthly_business_summary(feat_df, future_df)

    pd.DataFrame(results).T.to_csv(f"{DATA_DIR}/model_results.csv")
    print("\nDone. Charts saved to:", CHART_DIR)
    print("Data files saved to:", DATA_DIR)
